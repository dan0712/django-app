<?php
/**
 * Template Name:  FAQ Page Template
 * Description: FAQ Page
 */
get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>



<div id="frequently-asked-questions" class="pagebuilder-content">


<section class="padding-top-large padding-bottom-large text-color-light bg-image-cover section-type-intro" id="section-1" style="background-color: #fff;background-image: url('https://www.bettermentinstitutional.com/wp-content/uploads/2014/10/Mockup4blue.jpg');">

	
</section>

<section class="padding-top-none padding-bottom-none text-color-light section-type-column" style="background-color: #A3C745;" id="section-3">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
            <h1 style="text-align: center;"><i class="fa fa-question-circle"></i> FAQs</h1>
            
            
            </div>
        
        </div>
    
    </div>

</section>

<section class="padding-top-normal padding-bottom-none  section-type-column" style="background-color: #fff;" id="section-topics">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
            	<h2 style="text-align: center;">Topics</h2>
            
            </div>
        
        </div>
    
    </div>

</section>

<section class="padding-top-none padding-bottom-normal  section-type-column" style="background-color: #fff;" id="section-18">

    <div class="container">
    
        <div class="row">
        
            <div class="six columns col">
            
                <h3><i class="fa fa-chevron-right"></i> <a href="#section-betterment-institutional-overview">Betterment Institutional overview</a></h3>
                <h3><i class="fa fa-chevron-right"></i> <a href="#section-accounts-and-access">Accounts and access</a></h3>
                <h3><i class="fa fa-chevron-right"></i> <a href="#section-pricing-and-fees">Pricing and fees</a></h3>
                <h3><i class="fa fa-chevron-right"></i> <a href="#section-deposits-withdrawals-transfers">Deposits, withdrawals, transfers</a></h3>
                <h3><i class="fa fa-chevron-right"></i> <a href="#section-custody-clearing-trading">Custody, clearing, trading</a></h3>
                <h3><i class="fa fa-chevron-right"></i> <a href="#section-investment-philosophy-and-portfolios">Investment philosophy and portfolios</a></h3>
                </div><div class="six columns col"><h3><i class="fa fa-chevron-right"></i> <a href="#integration">Integration</a></h3>
                <h3><i class="fa fa-chevron-right"></i> <a href="#section-compliance">Compliance</a></h3>
                <h3><i class="fa fa-chevron-right"></i> <a href="#section-taxes-and-tax-loss-harvesting">Taxes and tax loss harvesting</a></h3>
                <h3><i class="fa fa-chevron-right"></i> <a href="#section-iras-and-rollovers">IRAs and Rollovers</a></h3>
                <h3><i class="fa fa-chevron-right"></i> <a href="#section-trust-accounts">Trust accounts</a></h3>
                <h3><i class="fa fa-chevron-right"></i> <a href="#section-returns">Returns</a></h3>
            
            </div>
        
        </div>
    
    </div>

</section>

<section class="padding-top-normal padding-bottom-normal  section-type-column" style="background-color: #f0f3f7;" id="section-betterment-institutional-overview">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
            	<h2 style="text-align: center;">Betterment Institutional overview</h2>
            
                <div class="nt-nt_accordions-wrap" data-active="0">
                
                    <div class="tab">
                    
                        <i class="nt-icon-plus"></i><i class="nt-icon-minus"></i> What is Betterment Institutional?
                    
                    </div>
                
                    <div class="pane clearfix">
                    
                    
                        <p>Betterment Institutional is a new solution for advisors and clients alike. Based on Betterment’s award-winning automated investment service, Betterment Institutional is designed to streamline the investment process and accelerate an advisor’s ability to serve their clientele. Betterment Institutional is the leading digital platform for advisors.</p>
                        <p>Betterment Institutional gives advisors the tools they need to change the experience for all parties in wealth advisory, and helps take care of front- and back-office operations. Advisor practices will become more productive, more efficient, and provide a next-generation interface for clients. With Betterment Institutional, advisors can bring cutting edge digital technology to their clients, automate their workflows, and spend time in front of customers, building new business and strengthening existing relationships.</p>
                    
                    </div>
                
                </div>
            	
                <h5><a href="#topics" class="button">Back to Top</a></h5>
            
            </div>
        
        </div>
    
    </div>

</section>


<section class="padding-top-normal padding-bottom-normal  section-type-column" style="background-color: #fff;" id="section-accounts-and-access">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
            	<h2 style="text-align: center;">Accounts and access</h2>
            
                <div class="nt-nt_accordions-wrap" data-active="0">
                
                    <div class="tab">
                    
                        <i class="nt-icon-plus"></i><i class="nt-icon-minus"></i> How does my firm sign up?
                    
                    </div>
                    
                    <div class="pane clearfix">
                    
                        <p>To sign up, please contact us <a href="https://www.bettermentinstitutional.com/connect/">here</a>. Once you are ready to sign up, it takes just a few minutes to get your firm up and running, and the entire sign up process is electronic.</p>
                    
                    </div>
                
                </div>
                
                <h5><a href="#topics" class="button">Back to Top</a></h5>
            
            </div>
        
        </div>
    
    </div>

</section>

<section class="padding-top-normal padding-bottom-normal  section-type-column" style="background-color: #f0f3f7;" id="section-pricing-and-fees">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
                <h2 style="text-align: center;">Pricing and fees</h2>
                
                <div class="nt-nt_accordions-wrap" data-active="0">
                
                    <div class="tab">
                        <i class="nt-icon-plus"></i><i class="nt-icon-minus"></i> What does Betterment Institutional cost?
                    </div>
                    <div class="pane clearfix">
                    
                        <p>There are no minimums, no upfront costs, and never any transaction costs for you or your clients. The asset management fees are divided into three components:</p>
                        <ol>
                        <li>The Betterment Institutional platform fee of 25 bps.</li>
                        <li>Your advisor fee on top of the platform fee (up to 125 bps).</li>
                        <li>The expenses for the underlying low-cost ETFs, which are paid out of dividends.</li>
                        </ol>
                        <p>Betterment Institutional also provides the flexibility for you to customize your fee for individual clients.</p>
                    </div>
                
                </div>
                
                
                <h5><a href="#topics" class="button">Back to Top</a></h5>
            
            
            </div>
        
        </div>
    
    </div>

</section>


<section class="padding-top-normal padding-bottom-normal  section-type-column" style="background-color: #fff;" id="section-deposits-withdrawals-transfers">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
                <h2 style="text-align: center;">Deposits, withdrawals, transfers</h2>
                
                <div class="nt-nt_accordions-wrap" data-active="0">
                    <div class="tab">
                        <i class="nt-icon-plus"></i><i class="nt-icon-minus"></i> How do clients fund their accounts?
                    </div>
                    
                    <div class="pane clearfix">
                        <p>We currently only allow electronic transfers to and from a client’s checking account through the ACH network. Electronic ACH transfers are easy, safe, and cost-effective. We do not accept credit or debit cards as funding sources.</p>
                        <p>For transfers greater than $300,000, we can provide wire transfers. Clients can access the wire instructions within the client experience. There is no fee from Betterment for wires, but clients should check with their bank for any applicable fees they may have.</p>
                        <p>During the signup process we will create an electronic link between a client’s existing checking account and their investment account. This electronic link makes it easy to transfer money whenever, for free. Once the link is set up, clients can make deposits and withdrawals on the Transfer tab.</p>
                    </div>
                
                
                </div>
                <h5><a href="#topics" class="button">Back to Top</a></h5>
            
            
            </div>
        
        </div>
    
    </div>

</section>


<section class="padding-top-large padding-bottom-large  section-type-column" style="background-color: #f0f3f7;" id="section-custody-clearing-trading">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
                <h2 style="text-align: center;">Custody, clearing, trading</h2>
                
                <div class="nt-nt_accordions-wrap" data-active="0">
                
                    <div class="tab">
                        <i class="nt-icon-plus"></i><i class="nt-icon-minus"></i> Who has custody of my clients’ assets?
                    </div>
                    <div class="pane clearfix">
                    
                        <p>Betterment Securities is full service broker dealer and member of FINRA and the Securities Investment Protection Corporation (“SIPC”).</p>
                        <p>Betterment Securities executes trades on your clients’ behalf and is the custodian of your clients’ assets, and functions similarly to Fidelity, Charles Schwab, or TD Ameritrade. This means Betterment Securities is responsible for handling your clients’ funds and keeping all records of their assets, which are reconciled every day against the records of Betterment Securities’ third-party clearing broker-dealer.</p>
                        <p>Serving as a full service broker dealer provides us with the flexibility to control the entire client experience without sacrificing safety of client assets.</p>
                    </div>
                
                </div>
                
                
                <h5><a href="#topics" class="button">Back to Top</a></h5>
            
            
            </div>
        
        </div>
    
    </div>

</section>

<section class="padding-top-large padding-bottom-large  section-type-column" style="background-color: #f0f3f7;" id="section-integration">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
                <h2 style="text-align: center;">Integration</h2>
                
                <div class="nt-nt_accordions-wrap" data-active="0">
                
                    <div class="tab">
                        <i class="nt-icon-plus"></i><i class="nt-icon-minus"></i> Do you integrate with any financial planning tools?
                    </div>
                    <div class="pane clearfix">
                    
                        <p>Yes, we currently integrate with <a href="http://www.emoneyadvisor.com/" target="_blank">eMoney Advisor</a> and <a href="https://www.moneyguidepro.com/" target="_blank">MoneyGuidePro</a> and have plans to expand integration with other financial planning tools in the near future.</p>
                    
                    </div>
                
                </div>
                
                
                <h5><a href="#topics" class="button">Back to Top</a></h5>
            
            
            </div>
        
        </div>
    
    </div>

</section>

<section class="padding-top-large padding-bottom-large  section-type-column" style="background-color: #fff;" id="section-compliance">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
                <h2 style="text-align: center;">Compliance</h2>
                
                <div class="nt-nt_accordions-wrap" data-active="0">
                
                    <div class="tab">
                    
                        <i class="nt-icon-plus"></i><i class="nt-icon-minus"></i> Can Betterment Institutional automate the signing of my agreement with my client?
                    
                    </div>
                    
                    <div class="pane clearfix">
                    
                        <p>Yes, you can provide PDF versions of your client agreement, ADV Part 2, and initial privacy disclosure to include as part of the electronic signup process. We also provide reporting in your dashboard about which versions your clients have agreed to, and when. Learn more <a href="https://www.bettermentinstitutional.com/agreement-automation">here</a>.</p>
                    
                    </div>
                
                
                </div>
                
                
                <h5><a href="#topics" class="button">Back to Top</a></h5>
            
            
            </div>
        
        </div>
    
    </div>

</section>

<section class="padding-top-large padding-bottom-large  section-type-column" style="background-color: #f0f3f7;" id="section-taxes-and-tax-loss-harvesting">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
                <h2 style="text-align: center;">Taxes and tax loss harvesting</h2>
                
                <div class="nt-nt_accordions-wrap" data-active="0">
                
                    <div class="tab">
                    
                        <i class="nt-icon-plus"></i><i class="nt-icon-minus"></i> When will clients tax forms available?
                    
                    </div>
                    
                    <div class="pane clearfix">
                    
                        <p>All tax forms for the 2014 tax year will be available for download by February 17, 2015. Clients will receive an email when their forms are generated and will be accessible via the Activity tab. Alternatively, clients can import the information automatically into TurboTax, H&amp;R Block, or TaxACT tax preparation software.</p>
                    <p>Tax forms for IRA accounts, including 1099-R forms (issued to customers who received an IRA distribution in 2014), and Fair Market Value and Required Minimum Distribution forms (issued to customers who had an IRA account with a balance in 2014), will be available for download by February 2, 2015.</p>
                    </div>
                
                
                </div>
                
                
                <h5><a href="#topics" class="button">Back to Top</a></h5>
            
            
            </div>
        
        </div>
    
    </div>

</section>

<section class="padding-top-large padding-bottom-large  section-type-column" style="background-color: #fff;" id="section-iras-and-rollovers">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
                <h2 style="text-align: center;">IRAs and Rollovers</h2>
                
                <div class="nt-nt_accordions-wrap" data-active="0">
                
                    <div class="tab">
                        <i class="nt-icon-plus"></i><i class="nt-icon-minus"></i> How do clients transfer 401ks or similar plans?
                    </div>
                    
                    <div class="pane clearfix">
                    
                        <p>We use the &#8220;direct rollover&#8221;method to prevent any withholding or negative tax consequences. A direct transfer entails a clients current provider sending us a check of the funds directly, for your clients benefit. To get started, you or your client can click &#8220;Rollover&#8221;at the top right hand side of your Summary page. You must answer a few questions, and receive an email with the full, personalized instructions, including how the check should be made out and where it should be sent, to complete your rollover. Please note that Traditional IRA funds must be rolled over into a Traditional IRA and Roth IRA funds must be rolled over into a Roth IRA. If you aren&#8217;t sure which type(s) of funds your clients have, contact the current provider or HR representative. You can always convert a Traditional IRA into a Roth IRA after the rollover.</p>
                    </div>
                
                </div>
                
                <h5><a href="#topics" class="button">Back to Top</a></h5>
            
            </div>
        
        </div>
    
    </div>

</section>

<section class="padding-top-large padding-bottom-large  section-type-column" style="background-color: #f0f3f7;" id="section-trust-accounts">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
                <h2 style="text-align: center;">Trust accounts</h2>
                
                <div class="nt-nt_accordions-wrap" data-active="0">
                
                <div class="tab">
                    <i class="nt-icon-plus"></i><i class="nt-icon-minus"></i> What types of trust accounts do you support?
                </div>
                
                <div class="pane clearfix">
                
                    <p>Betterment supports both revocable and irrevocable trusts that are authorized to invest in securities. In order to open a trust account the trust has to be a U.S. domestic trust, have been previously established, and is in good legal standing.</p>
                
                </div>
                
                </div>
                
                
                <h5><a href="#topics" class="button">Back to Top</a></h5>
            
            </div>
        
        </div>
    
    </div>

</section>

<section class="padding-top-large padding-bottom-large  section-type-column" style="background-color: #fff;" id="section-returns">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
                <h2 style="text-align: center;">Returns</h2>
                
                <div class="nt-nt_accordions-wrap" data-active="0">
                
                <div class="tab">
                    <i class="nt-icon-plus"></i><i class="nt-icon-minus"></i> How do you calculate returns?
                </div>
                
                <div class="pane clearfix">
                    <p>We use a standard time-weighted return to calculate percentage returns for each goal on the Summary page, and to display returns over time on the Performance page. This return can be thought of as the amount one dollar would have changed if it was invested at the same time as a first deposit.</p>
                    <p>The time-weighted return is unaffected by deposits to and withdrawals from an account, and allows for easy assessment of clients’ investments, and a fair comparison with other investments.</p>
                
                </div>
                
                </div>
                
                <h5><a href="#topics" class="button">Back to Top</a></h5>
            </div>
        
        </div>
    
    </div>

</section>

</div>



<?php endwhile; endif; ?>

<?php get_footer(); ?>