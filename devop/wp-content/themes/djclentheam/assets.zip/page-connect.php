<?php
/**
 * Template Name:  Connect Page Template
 * Description: Connect Page
 */
get_header(); ?>

<?php if (have_posts()) : while (have_posts()) : the_post(); ?>


<div id="connect" class="pagebuilder-content">

<section class="padding-top-normal padding-bottom-normal  bg-image-cover section-type-intro" id="section-1" style="background-color: #fff;background-image: url('<?php the_field('section_1_bg'); ?>');">

	
    <div class="row section-content">
    
        <div class="eight col center text-center">
        
            <div class="intro-section-content section-content-wrap">
            
            	<?php the_field('section_1_content'); ?>
                
            
                <div class="row">
                
                <?php if(get_field('section_1_content_2')): while(has_sub_field('section_1_content_2')): ?>
                <div class="six columns col">
                
                	<?php the_sub_field('section_1_sub_content'); ?>
                    
                
                </div>
                <?php endwhile; endif; ?>
 
                
                </div>
            
            </div>
        
        </div>
    
    </div>

	
	
</section>


<section class="padding-top-normal padding-bottom-normal  section-type-column" style="background-color: <?php the_field('section_2_bg_color'); ?>;" id="section-form-sign-up">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
            	<?php the_field('section_2_content'); ?>
                
            
            </div>
        
        </div>
    
    </div>

</section>

<section class="padding-top-normal padding-bottom-normal  section-type-column" style="background-color: <?php the_field('section_3_bg_color'); ?>;" id="section-form-schedule-demo">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
            	
                <?php the_field('section_3_content'); ?>
                
            
            </div>
        
        </div>
    
    </div>

</section>

<section class="padding-top-normal padding-bottom-large text-color-light section-type-column" style="background-color: #617921;" id="section-5">

    <div class="container">
    
        <div class="row">
        
            <div class="twelve columns col">
            
            	
                <?php if ( !function_exists('dynamic_sidebar')|| !dynamic_sidebar('sidebar_1') ) : endif; ?>
            
            </div>
        
        </div>
    
    </div>

</section>

</div>


<?php endwhile; endif; ?>

<?php get_footer(); ?>